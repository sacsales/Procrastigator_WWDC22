import SwiftUI
import SpriteKit
/*
 
 important: if running this project on a mac, please set the simulator to ipad pro (9.7-inch) as it looks best on that screen (other models of ipad pro look good as well.) it doesn't look good on the live view, so please use the simulator!  if running on an ipad, please give it time to compile :)
 
 beep boop

 hello again!
 
 my name is sabrina, and this is my second time submitting an entry to the swift student challenge. i'm happy to share that my submission was accepted last year, and i'm really excited to be sharing something with you again!
 
 attending wwdc virtually last year was one of the coolest things i've experienced.  i've learned so much and still have so much to learn now!
 
 thanks for taking the time to view my submission! I hope you have as much fun playing this as i had creating this.
 
 as always, have an awesome day/night :]
 
 - sabrina, now 13!
 
 */
//MARK: Title Screen
class TitleScene: SKScene {
    
    let startButton = SKSpriteNode(imageNamed: "startButtonTexture")
    let bg = SKSpriteNode(imageNamed: "titleBg1")
    let header = SKSpriteNode(imageNamed: "titleHeader")
    let text = SKLabelNode(text: "Please rotate your device to landscape :)")
    
    override func didMove(to view: SKView){
    
        
        startButton.size = CGSize(width: 300, height: 125)
        startButton.position = CGPoint(x: 600, y: 500)
        startButton.name = "startButton"
        
        bg.size = self.size
        bg.position = CGPoint(x: 600, y: 500)
        bg.zPosition = -1
        
        header.size = CGSize(width: 900, height: 125)
        header.position = CGPoint(x: 600, y: 700)
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        
        let pulse1 = SKAction.fadeAlpha(to: 0.1, duration: 1.0)
        let pulse2 = SKAction.fadeAlpha(to: 1, duration: 1.0)
        
        let pulseSeq = SKAction.sequence([pulse1,pulse2])
        
        let floatUp = SKAction.moveBy(x: 0, y: 10, duration: 1.0)
        let floatDown = SKAction.moveBy(x: 0, y: -10, duration: 1.0)
        
        let floatSeq = SKAction.sequence([floatUp,floatDown])
        
        text.fontName = "AvenirNext-Medium"
        text.fontSize = 36.0
        text.numberOfLines = 0
        text.position = CGPoint(x: 600, y: 575)
        text.fontColor = #colorLiteral(red: 0, green: 0.3003850281, blue: 0.2117901742, alpha: 1)
    
        startButton.run(.repeatForever(pulseSeq))
        header.run(.repeatForever(floatSeq))
        
        self.addChild(startButton)
        self.addChild(bg)
        self.addChild(header)
        self.addChild(text)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        startButton.name = "startButton"
        
        for touch in touches {
            
             let location = touch.location(in: self)
             let touchedNode = atPoint(location)
            
            if touchedNode.name == "startButton" {
                
                
                var scene:SKScene = IntroScene(size: self.size)
                self.view?.presentScene(scene)
                
            }
            
        }
        
     }

}

//MARK: Slideshow
class IntroScene: SKScene {
    
    var shouldChangeScreen = false
    
    let heyHeader = SKLabelNode(text: "Hey! This is Gator.")
    let colorBg = SKSpriteNode(color: .systemGreen, size: CGSize( width: 1200, height: 1000))
    
    let para1 = SKLabelNode(text: """
Gator is struggling with procrastination.
Procrastination is the act of delaying or putting off 
tasks until the last minute.
It happens to just about anyone.
There are ways to combat this!

Help Gator along his journey to conquer his to-do list!

""")
    
    let nextButton = SKSpriteNode(imageNamed: "nextButtonTexture")
    
    let pageImage = SKSpriteNode(imageNamed: "gator_walk_left_1")
    
    override func didMove(to view: SKView){
        
        heyHeader.position = CGPoint(x: 150, y: 750)
        heyHeader.horizontalAlignmentMode = .left
        heyHeader.name = "heyHeader"
        heyHeader.fontSize = 38.0
        heyHeader.fontName = "AvenirNext-Heavy"
        heyHeader.numberOfLines = 0
        heyHeader.fontColor = #colorLiteral(red: 0, green: 0.3003850281, blue: 0.2117901742, alpha: 1)
        heyHeader.zPosition = 3
        
        
        colorBg.position = CGPoint(x: 600, y: 500)
        colorBg.color = #colorLiteral(red: 0.6378648877, green: 0.7980249524, blue: 0.5365267396, alpha: 1)
        
        para1.fontName = "AvenirNext-Medium"
        para1.fontSize = 36.0
        para1.numberOfLines = 0
        para1.horizontalAlignmentMode = .left
        para1.position = CGPoint(x: 150, y: 400)
        para1.fontColor = #colorLiteral(red: 0, green: 0.3003850281, blue: 0.2117901742, alpha: 1)
        
        nextButton.size = CGSize(width: 300, height: 125)
        nextButton.position = CGPoint(x: 600, y: 200)
        nextButton.name = "nextButton"
        
        pageImage.size = CGSize(width: 300, height: 100)
        pageImage.position = CGPoint(x: 900, y: 780)
        pageImage.name = "pageImage"
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        
        
        
    
        
        self.addChild(heyHeader)
        self.addChild(colorBg)
        self.addChild(para1)
        self.addChild(nextButton)
        self.addChild(pageImage)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
            
             let location = touch.location(in: self)
             let touchedNode = atPoint(location)
            
            if touchedNode.name == "nextButton" {
               
                
                if shouldChangeScreen == true {
                    
                    var scene:SKScene = Level1Scene(size: self.size)
                    self.view?.presentScene(scene)
                        
                }
                   
                }
                
                if shouldChangeScreen == false {
                    
                para1.text = """
Follow the instructions on the objective screens
on each level to complete the game.

Have fun, and good luck!
"""
                    para1.run(SKAction.moveBy(x: 0, y: 120, duration: 0.5))
                    //pageImage.texture = SKTexture(imageNamed: "allMoveButtons")
                    //pageImage.size = CGSize(width: 250, height: 200)
                   // pageImage.run(SKAction.moveBy(x: 0, y: -150, duration: 0.5))
                    pageImage.isHidden = true
                    heyHeader.text = "Objectives"
                shouldChangeScreen = true
                    
                }
            }
            
        }
    }

//MARK: Level 1
class Level1Scene: SKScene {
    
    var toDoStage = 0
    
    let colorBg = SKSpriteNode(color: .systemGreen, size: CGSize( width: 1200, height: 1000))
    let header = SKLabelNode(text: "Level 1a: Objective")
    
    let para1 = SKLabelNode(text: """

Gator has a few tasks
to complete today.
Help him organise them into
a to-do list by clicking the
tasks below in the correct
order!

""")
    
    let toDoRead = SKSpriteNode(imageNamed: "toDoRead")
    let toDoTidy = SKSpriteNode(imageNamed: "toDoTidy")
    let toDoDeliver = SKSpriteNode(imageNamed: "toDoDeliver")
    
    
    let nextButton = SKSpriteNode(imageNamed: "nextButtonTexture")
    
    let toDoList = SKSpriteNode(imageNamed: "gator'sListBack")
    
    let tdGuide1 = SKSpriteNode(color: .cyan, size: CGSize(width: 400, height: 70))
    let tdGuide2 = SKSpriteNode(color: .cyan, size: CGSize(width: 400, height: 70))
    let tdGuide3 = SKSpriteNode(color: .cyan, size: CGSize(width: 400, height: 70))
    
    let tipBg = SKSpriteNode(color: #colorLiteral(red: 0.300241679, green: 0.6219526529, blue: 0.7733848691, alpha: 1), size: CGSize(width: 600, height: 500))
    let tipHeader = SKLabelNode(text: "Great Job!")
    let tipText = SKLabelNode(text:
    """
    Awesome! Creating to-do lists gives you a
    clearer idea of the tasks you need to
    complete that day.
    They stop you from forgetting things and
    help to prioritise tasks. Let's go help
    Gator tackle the first item on his list
    today:
    Delivering items to a friend.
    """)
    
    
    
    override func didMove(to view: SKView) {
        
       
        
        colorBg.position = CGPoint(x: 600, y: 500)
        colorBg.color = #colorLiteral(red: 0.6378648877, green: 0.7980249524, blue: 0.5365267396, alpha: 1)
        colorBg.zPosition = -3
        header.position = CGPoint(x: 150, y: 750)
        header.horizontalAlignmentMode = .left
        header.fontSize = 38.0
        header.fontName = "AvenirNext-Heavy"
        header.numberOfLines = 0
        header.fontColor = #colorLiteral(red: 0, green: 0.3003850281, blue: 0.2117901742, alpha: 1)
        header.zPosition = 3
        
        para1.fontName = "AvenirNext-Medium"
        para1.fontSize = 32.0
        para1.numberOfLines = 0
        para1.horizontalAlignmentMode = .left
        para1.position = CGPoint(x: 150, y: 475)
        para1.fontColor = #colorLiteral(red: 0, green: 0.3003850281, blue: 0.2117901742, alpha: 1)
        
        tipText.fontName = "AvenirNext-Medium"
        tipText.fontSize = 28.0
        tipText.numberOfLines = 0
        tipText.horizontalAlignmentMode = .left
        tipText.position = CGPoint(x: 320, y: 340)
        tipText.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        
        tipHeader.position = CGPoint(x: 320, y: 650)
        tipHeader.horizontalAlignmentMode = .left
        tipHeader.fontSize = 38.0
        tipHeader.fontName = "AvenirNext-Heavy"
        tipHeader.numberOfLines = 0
        tipHeader.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        tipHeader.zPosition = 3
        
        let toDoSize = CGSize(width: 400, height: 80)
        
        toDoRead.size = toDoSize
        toDoTidy.size = toDoSize
        toDoDeliver.size = toDoSize
        
        toDoRead.position = CGPoint(x: 350, y: 400)
        toDoTidy.position = CGPoint(x: 350, y: 300)
        toDoDeliver.position = CGPoint(x: 350, y: 200)
        
        toDoRead.name = "toDoRead"
        toDoTidy.name = "toDoTidy"
        toDoDeliver.name = "toDoDeliver"
        
        toDoList.size = CGSize(width: 500, height: 600)
        toDoList.position = CGPoint(x: 850, y: 500)
        toDoList.zPosition = -1
        
        tdGuide1.position = CGPoint(x: 850, y: 610)
        tdGuide1.isHidden = true
        
        tdGuide2.position = CGPoint(x: 850, y: 520)
        tdGuide2.isHidden = true
        tdGuide3.position = CGPoint(x: 850, y: 420)
        tdGuide3.isHidden = true
        
        tipBg.position = CGPoint(x: 600, y: 500)
        tipBg.alpha = 0
        tipHeader.alpha = 0
        tipText.alpha = 0
        
        nextButton.position = CGPoint(x: 800, y: 300)
        nextButton.size = CGSize(width: 180, height: 80)
        nextButton.alpha = 0
        nextButton.name = "nextButton"
        
        self.addChild(colorBg)
        self.addChild(header)
        self.addChild(para1)
        
        self.addChild(toDoRead)
        self.addChild(toDoTidy)
        self.addChild(toDoDeliver)
        
        self.addChild(toDoList)
        self.addChild(tdGuide1)
        self.addChild(tdGuide2)
        self.addChild(tdGuide3)
        
        
        self.addChild(tipBg)
        self.addChild(tipHeader)
        self.addChild(tipText)
        self.addChild(nextButton)
        
        
    }
        
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            
        for touch in touches {
            
             let location = touch.location(in: self)
             let touchedNode = atPoint(location)
            
            if touchedNode.name == "nextButton" {
                
                       
                        var scene:SKScene = Level1GameScene(size: self.size)
                        self.view?.presentScene(scene)
                            
                    
        }
            
        if toDoStage == 0 {
            if touchedNode.name == "toDoDeliver" {
                
                toDoDeliver.run(SKAction.move(to:tdGuide1.position, duration: 0.5))
                toDoDeliver.run(SKAction.scale(to: tdGuide1.size, duration: 0.5))
                toDoStage = 1
                
        }
            
        } else if toDoStage == 1 {
            
            if touchedNode.name == "toDoRead" {
            toDoRead.run(SKAction.move(to: tdGuide2.position, duration: 0.5))
            toDoRead.run(SKAction.scale(to: tdGuide2.size, duration: 0.5))
                
                toDoStage = 2
            }
            
        } else if toDoStage == 2 {
            
            if touchedNode.name == "toDoTidy" {
              toDoTidy.run(SKAction.move(to: tdGuide3.position, duration: 0.5))
              toDoTidy.run(SKAction.scale(to: tdGuide3.size, duration: 0.5))
                
                
                tipBg.run(SKAction.fadeIn(withDuration: 1.0))
                tipText.run(SKAction.fadeIn(withDuration: 1.0))
                tipHeader.run(SKAction.fadeIn(withDuration: 1.0))
                nextButton.run(SKAction.fadeIn(withDuration: 1.5))
                /*
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {  nextButton.run(SKAction.fadeAlpha(to: 1, duration: 1.0))
                }
                */
              toDoStage = 3
                
                
            }
            
        }
      }
            
    }
  }

//MARK: Level 1.5
let gatorSize = CGSize(width: 150, height: 50)

class Level1GameScene: SKScene, SKPhysicsContactDelegate {
    
    let gatorCategory:    UInt32 = 1 << 1
    let frogCategory:   UInt32 = 1 << 2
    let groundCategory: UInt32 = 1  << 3
    
    let jumpUpAction = SKAction.moveBy(x: 0, y: 100, duration: 0.5)
    // move down 20
    let jumpDownAction = SKAction.moveBy(x: 0, y: -100, duration: 0.5)
    // sequence of move up then down
   
    
    //stuff made here
    
    let gator = SKSpriteNode(imageNamed: "gator_walk_right_1")
    let up2 = SKSpriteNode(imageNamed: "upButton2")
    let left2 = SKSpriteNode(imageNamed: "leftButton2")
    let right2 = SKSpriteNode(imageNamed: "rightButton2")
    
    let mothJar = SKSpriteNode(imageNamed: "jarOfMoths")
    
    let frog = SKSpriteNode(imageNamed: "frog")
    let ground = SKSpriteNode(imageNamed: "ground 2")
    
    let block1 = SKSpriteNode(imageNamed: "block1")
    let floatyBlock = SKSpriteNode(imageNamed: "smallBlock2")
    
    //texture stuff
    
    let walkR1 = SKTexture(imageNamed: "gator_walk_right_1")
    let walkR2 = SKTexture(imageNamed: "gator_walk_right_2")
    
    let walkL1 = SKTexture(imageNamed: "gator_walk_left_2")
    let walkL2 = SKTexture(imageNamed: "gator_walk_left_2")
    
    let colorBg = SKSpriteNode(color: .systemGreen, size: CGSize( width: 1200, height: 1000))
    
    let frogSpeechBg = SKSpriteNode(color: #colorLiteral(red: 0.6876877546, green: 0.9086436629, blue: 0.9380626678, alpha: 1) , size: CGSize(width: 1000, height: 400))
    let frogSpeechText = SKLabelNode(text: """

"Gator! You brought me my moths.
Thanks a bunch - must've been quite a journey up here..
You know, taking the magic floating bush and all. I have no idea why
it does that. Anywho, see ya later, (Alli)-Gator! (I had to.)"

""")
    let frogSpeechHeader = SKLabelNode(text: "Frog")
    let frogSpeechPic = SKSpriteNode(imageNamed: "frog")
    
    let seeYa = SKSpriteNode(imageNamed: "seeYaButtonTexture")
    
    let objectBg = SKSpriteNode(color: #colorLiteral(red: 0.300241679, green: 0.6219526529, blue: 0.7733848691, alpha: 1), size: CGSize(width: 500, height: 200))
    let objectBgHead = SKLabelNode(text: "Level 1b: Objective")
    let objectText = SKLabelNode(text: """
Use the move buttons on the left side
of the screen to help Gator deliver
the jar of moths he's carrying to frog.
""")
    
    override func didMove(to view: SKView) {
        
        let liftUp = SKAction.moveBy(x: 0, y: 400, duration: 2.0)
        let liftWait = SKAction.wait(forDuration: 0.7)
        let liftDown = SKAction.moveBy(x: 0, y: -400, duration: 2.0)
        
        let liftSequence = SKAction.sequence([liftUp, liftWait, liftDown, liftWait])
        
        floatyBlock.run(.repeatForever(liftSequence))
        
        
        physicsWorld.contactDelegate = self

        physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        physicsBody?.restitution = 1
        
        up2.size = CGSize(width: 94, height: 91)
        up2.position = CGPoint(x: 200, y: 300)
        up2.name = "up2"
        left2.size = CGSize(width: 94, height: 91)
        left2.position = CGPoint(x: 150, y: 200)
        left2.name = "left2"
        right2.size = CGSize(width: 94, height: 91)
        right2.position = CGPoint(x: 250, y: 200)
        right2.name = "right2"
        
        up2.zPosition = 2
        
        
        
        
        gator.position = CGPoint(x: 500, y: 500)
        gator.zPosition = -2
        gator.size = gatorSize
        gator.physicsBody = SKPhysicsBody(rectangleOf: gatorSize)
        gator.physicsBody?.categoryBitMask = gatorCategory
        
        
        frog.position = CGPoint(x: 500, y: 900)
        frog.zPosition = -2
        frog.size = CGSize(width: 100, height: 100)
        frog.physicsBody = SKPhysicsBody(rectangleOf: frog.size)
        frog.physicsBody?.categoryBitMask = frogCategory
        
        mothJar.position = CGPoint(x: 500, y: 550)
        mothJar.zPosition = -2
        mothJar.size = CGSize(width: 70, height: 70)
        mothJar.physicsBody = SKPhysicsBody(rectangleOf: mothJar.size)
        //make things, add properties.
        
        colorBg.position = CGPoint(x: 600, y: 500)
        colorBg.color = #colorLiteral(red: 0.6378648877, green: 0.7980249524, blue: 0.5365267396, alpha: 1)
        colorBg.zPosition = -3
        
        ground.size = CGSize(width: self.size.width, height: 400)
        ground.position = CGPoint(x: 600, y: 200)
        ground.zPosition = -2
        ground.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: ground.size.width, height: ground.size.height - 50))
        
        ground.physicsBody?.restitution = 0
        ground.physicsBody?.isDynamic = false
        ground.physicsBody?.categoryBitMask = groundCategory
        
        block1.size = CGSize(width: 900, height: 190)
        block1.position = CGPoint(x: 600, y: 600)
        block1.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: block1.size.width, height: block1.size.height - 50))
        block1.physicsBody?.isDynamic = false
        
        floatyBlock.size = CGSize(width: 450, height: 190)
        floatyBlock.position = CGPoint(x: 1200, y: 290)
        floatyBlock.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: floatyBlock.size.width, height: floatyBlock.size.height - 50))
        floatyBlock.physicsBody?.isDynamic = false
        
        
        gator.physicsBody?.collisionBitMask = 0
        floatyBlock.physicsBody?.collisionBitMask = 0
        block1.physicsBody?.collisionBitMask = 0
        frog.physicsBody?.collisionBitMask = 0
        //slopeBlock.physicsBody?.collisionBitMask = 0
        
       gator.physicsBody?.collisionBitMask = groundCategory
        frog.physicsBody?.collisionBitMask = groundCategory
        
        gator.physicsBody?.contactTestBitMask =
                                        frogCategory
        frog.physicsBody?.contactTestBitMask =
                                        gatorCategory
       
        let pinJoint = SKPhysicsJointPin.joint(withBodyA: gator.physicsBody!, bodyB: mothJar.physicsBody!,
                                               anchor: mothJar.position)
        
        frogSpeechBg.position = CGPoint(x: 600, y: 400)
        frogSpeechBg.zPosition = 1
        
        frogSpeechText.fontName = "AvenirNext-Medium"
        frogSpeechText.fontSize = 28.0
        frogSpeechText.numberOfLines = 0
        frogSpeechText.horizontalAlignmentMode = .left
        frogSpeechText.position = CGPoint(x: 150, y: 330)
        frogSpeechText.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        frogSpeechText.zPosition = 3
        
        frogSpeechHeader.position = CGPoint(x: 150, y: 500)
        frogSpeechHeader.horizontalAlignmentMode = .left
        frogSpeechHeader.fontSize = 38.0
        frogSpeechHeader.fontName = "AvenirNext-Heavy"
        frogSpeechHeader.numberOfLines = 0
        frogSpeechHeader.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        frogSpeechHeader.zPosition = 3
        
        
        frogSpeechPic.size = CGSize(width: 300, height: 300)
        frogSpeechPic.position = CGPoint(x: 250, y: 650)
        frogSpeechPic.zPosition = 0
        
        seeYa.size = CGSize(width: 200, height: 90)
        seeYa.position = CGPoint(x: 950, y: 270)
        seeYa.zPosition = 3
        
        frogSpeechPic.alpha = 0
        frogSpeechBg.alpha = 0
        frogSpeechText.alpha = 0
        frogSpeechHeader.alpha = 0
        seeYa.alpha = 0
        seeYa.name = "seeYa"
        
        objectBg.position = CGPoint(x: 900, y: 225)
        
        objectText.fontName = "AvenirNext-Medium"
        objectText.fontSize = 24.0
        objectText.numberOfLines = 0
        objectText.horizontalAlignmentMode = .left
        objectText.position = CGPoint(x: 675, y: 160)
        objectText.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        
        objectBgHead.fontName = "AvenirNext-Heavy"
        objectBgHead.fontSize = 24.0
        objectBgHead.numberOfLines = 0
        objectBgHead.horizontalAlignmentMode = .left
        objectBgHead.position = CGPoint(x: 675, y: 265)
        objectBgHead.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        
        
        self.addChild(gator)
        
        
        self.addChild(left2)
        self.addChild(right2)
        self.addChild(colorBg)
        self.addChild(ground)
        self.addChild(block1)
        
        self.addChild(floatyBlock)
        self.addChild(frog)
        self.addChild(mothJar)
        self.physicsWorld.add(pinJoint)
        
        self.addChild(frogSpeechText)
        self.addChild(frogSpeechBg)
        self.addChild(frogSpeechHeader)
        self.addChild(frogSpeechPic)
        self.addChild(seeYa)
        self.addChild(objectBg)
        self.addChild(objectText)
        self.addChild(objectBgHead)
        
        
    }
        
    
    func didBegin(_ contact: SKPhysicsContact) {
       
             let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask

             switch contactMask {
             case gatorCategory | frogCategory:
               
                 
                 
                 DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                     
                     self.frogSpeechBg.run(SKAction.fadeAlpha(to: 1, duration: 0.5))
                     self.frogSpeechText.run(SKAction.fadeAlpha(to: 1, duration: 0.5))
                     self.frogSpeechHeader.run(SKAction.fadeAlpha(to: 1, duration: 0.5))
                     self.frogSpeechPic.run(SKAction.fadeAlpha(to: 1, duration: 0.5))
                     self.seeYa.run(SKAction.fadeAlpha(to: 1, duration: 0.5))
                     self.objectBg.isHidden = true
                     self.objectBgHead.isHidden = true
                     self.objectText.isHidden = true
                 }
                 
                 
             default:
                print("Some other contact occurred")
                 
             }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            
        let jumpSequence = SKAction.sequence([jumpUpAction, jumpDownAction])
        let moveRight = SKAction.moveBy(x: 200, y: 0, duration: 0.5)
        let moveLeft = SKAction.moveBy(x: -200, y: 0, duration: 0.5)

        let gatorRightTextures = [walkR1, walkR2]
        let gatorLeftTextures = [walkL1, walkL2]
        
        let rightAnimate = SKAction.animate(with: gatorRightTextures, timePerFrame: 0.1)
        let leftAnimate = SKAction.animate(with: gatorLeftTextures, timePerFrame: 0.1)
        
        
        
         for touch in touches {
             
              let location = touch.location(in: self)
              let touchedNode = atPoint(location)
             
             
              if touchedNode.name == "left2" {
                  //gator.physicsBody?.applyImpulse(CGVector(dx:-200 , dy:0))
                  gator.run(moveLeft)
                  gator.run(leftAnimate)
                  
              } else if touchedNode.name == "right2" {
                  gator.run(moveRight)
                  //gator.physicsBody?.applyImpulse(CGVector(dx:200 , dy:0))
                  gator.run(rightAnimate)
                 
             } else if touchedNode.name == "up2"{
                 //gator.physicsBody?.applyImpulse(CGVector(dx:0 , dy:200))
                 gator.run(jumpSequence)
                
             }
              
             if touchedNode.name == "backButton" {
                 
                 gator.position = CGPoint(x: -400, y: -50)
                
             }
             
             if touchedNode.name == "seeYa" {
                
                 
                 
                 
                 var scene:SKScene = Level2Scene(size: self.size)
                 self.view?.presentScene(scene)
                 
             }
            
                 
             
         }
      }
    }
    


public var timerCounter = 0

//MARK: Level 2 Scene
class Level2Scene: SKScene, SKPhysicsContactDelegate {
    
    
    let gatorCategory:    UInt32 = 1 << 1
    let cometCategory:   UInt32 = 1 << 2
    let groundCategory: UInt32 = 1  << 3
    let checkerCategory: UInt32 = 1  << 4
    
    let book = SKSpriteNode(imageNamed: "book")
    let gator = SKSpriteNode(imageNamed: "gator_walk_right_1")
    let ground = SKSpriteNode(color: .darkGray, size: CGSize(width: 1200, height: 400))
    
    let popUp = SKSpriteNode(color: #colorLiteral(red: 0.300241679, green: 0.6219526529, blue: 0.7733848691, alpha: 1), size: CGSize(width: 1000, height: 400))
    let popUpHeader = SKLabelNode(text: "Level 2: Objective")
    let popUpText = SKLabelNode(text: """
'Distractions' are raining from the sky!
Quick! Protect Gator while he completes the next task on his list
- reading a book - by clicking on them before they hit him.
Click next to start!
""")
    let popUpButton = SKSpriteNode(imageNamed: "nextButtonTexture")
    let endingChecker = SKSpriteNode(color: .red, size: CGSize(width: 300, height: 200))
    
    override func didMove(to view: SKView) {
        
       
        
        endingChecker.texture = SKTexture(imageNamed: "taskCompleted")
        endingChecker.position = CGPoint(x: 1000, y: 400)
        endingChecker.physicsBody = SKPhysicsBody(rectangleOf: endingChecker.size)
        endingChecker.physicsBody?.categoryBitMask = checkerCategory
        endingChecker.physicsBody?.isDynamic = false
        endingChecker.physicsBody?.contactTestBitMask = gatorCategory
        endingChecker.physicsBody?.collisionBitMask = 0
        
        gator.position = CGPoint(x: 100, y: 500)
        gator.zPosition = -2
        gator.size = gatorSize
        gator.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: "gator_walk_right_1"), size: gatorSize)
        
        book.position = CGPoint(x: 200, y: 500)
        book.zPosition = -2
        book.size = CGSize(width: 100, height: 100)
        book.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: "book"), size: book.size)
        book.physicsBody?.collisionBitMask = groundCategory
        
        
        let gatorJoint = SKPhysicsJointPin.joint(withBodyA: gator.physicsBody!, bodyB: book.physicsBody!,
                                               anchor: book.position)
        
        ground.physicsBody = SKPhysicsBody(rectangleOf: ground.size)
        ground.position = CGPoint(x: 600, y: 100)
        
        popUp.position = CGPoint(x: 600, y: 500)
        popUp.zPosition = 5
        
        popUpHeader.horizontalAlignmentMode = .left
        popUpHeader.position = CGPoint(x: 150, y: 600)
        popUpHeader.zPosition = 5
        popUpHeader.fontName = "AvenirNext-Heavy"
        popUpHeader.fontColor = .black
        
        popUpText.position = CGPoint(x: 150, y: 410)
        popUpText.zPosition = 5
        popUpText.horizontalAlignmentMode = .left
        popUpText.fontName = "AvenirNext-Medium"
        popUpText.fontColor = .black
        popUpText.numberOfLines = 0
        
        popUpButton.size = CGSize(width: 200, height: 90)
        popUpButton.position = CGPoint(x: 900, y: 400)
        popUpButton.zPosition = 5
        popUpButton.name = "popUpButton"
        
        ground.physicsBody?.isDynamic = false
        ground.physicsBody?.categoryBitMask = groundCategory
        gator.physicsBody?.categoryBitMask = gatorCategory
        gator.physicsBody?.collisionBitMask = groundCategory
        gator.physicsBody?.contactTestBitMask = checkerCategory
        
        physicsWorld.contactDelegate = self
        
        physicsWorld.gravity = CGVector(dx: 0, dy: -1.62)

        physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        physicsBody?.restitution = 0
        
        self.addChild(gator)
        
        
        
        self.addChild(ground)
        self.addChild(popUp)
        self.addChild(popUpHeader)
        self.addChild(popUpText)
        self.addChild(popUpButton)
        self.addChild(endingChecker)
        self.addChild(book)
        self.physicsWorld.add(gatorJoint)
        let goBack = SKAction.moveTo(x: 100, duration: 0.01)
        
        
    }
    
    var shouldChangeScreen = false
    public var shouldTimerContinue = true
    
    func timerThing() {
        
        gator.run(SKAction.moveTo(x: 1100, duration: 20.0))
       let timer =  Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [self] timer in
           if shouldTimerContinue == false {
               timer.invalidate()
           }
           
            let randomX = Int.random(in: 1..<1000)
           
            let randomImageInt = Int.random(in:1..<4)
            
           let comet = SKSpriteNode(imageNamed: "distract1")
           
           if randomImageInt == 1 {
               
               comet.texture = SKTexture(imageNamed: "distract1")
               
           }
           
           if randomImageInt == 2 {
               
               comet.texture = SKTexture(imageNamed: "distract2")
               
           }
           
           if randomImageInt == 3 {
               
               comet.texture = SKTexture(imageNamed: "distract3")
           }
           
           
           comet.name = "comet"
           comet.position = CGPoint(x: randomX, y: 999)
           comet.size = CGSize(width: 200, height: 200)
           comet.physicsBody = SKPhysicsBody(rectangleOf: comet.size)
            
           comet.physicsBody?.categoryBitMask = cometCategory
           comet.physicsBody?.collisionBitMask = 0
           comet.physicsBody?.contactTestBitMask = groundCategory | gatorCategory
            
           self.addChild(comet)
        }
        
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
       
        let goBack = SKAction.moveTo(x: 100, duration: 0.01)
        
             let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        
             switch contactMask {
             case cometCategory | groundCategory:
                print("comet on ground")
                 contact.bodyB.node?.isHidden = true
                 
                 
             case cometCategory | gatorCategory:
                 print("gator's been hit :(")
                 gator.removeAllActions()
                 gator.run(goBack)
                 popUp.isHidden = false
                 popUpHeader.isHidden = false
                 popUpText.isHidden = false
                 popUpButton.isHidden = false
                 popUpHeader.text = "Oh No!"
                 popUpText.text = """
Gator got distracted!
Make sure to click on the distractions before they hit him
to let him finish his task. Try again?
"""
                 timerCounter = 0
                 shouldTimerContinue = false
             case gatorCategory | checkerCategory:
                 
                 shouldTimerContinue = false
                 popUp.isHidden = false
                 popUpHeader.isHidden = false
                 popUpText.isHidden = false
                 popUpButton.isHidden = false
                 popUpHeader.text = "You did it!"
                 popUpHeader.position = CGPoint(x: popUpHeader.position.x, y: 610)
                 popUpText.position = CGPoint(x: popUpText.position.x, y: 400)
                 popUpText.text = """
Thanks to your help, Gator just completed another task without
distractions! Removing distractions help you focus on the
task at hand. A good way to do this is to work at a well-lit,
clutter-free and organised desk.
"""
                 gator.removeFromParent()
                 shouldChangeScreen = true
             default:
                print("Some other contact occurred")
                 
             }
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
                let location = touch.location(in: self)
                let touchedNode = atPoint(location)
                if touchedNode.name == "popUpButton" {
                    if shouldChangeScreen == true {
                        
                        var scene:SKScene = Level3Scene(size: self.size)
                        self.view?.presentScene(scene)
                        
                        
                    }
                    popUpButton.isHidden = true
                    popUpHeader.isHidden = true
                    
                    
                    popUpText.isHidden = true
                    
                    popUp.isHidden = true
                    shouldTimerContinue = true
                    timerThing()
                    
            }
            
            if touchedNode.name == "comet" {
                touchedNode.removeFromParent()
            }
        }
    }
    
    
    
    
}



let ShapeCategory:    UInt32 = 1 << 1
let PatternCategory:   UInt32 = 1 << 2

//MARK: Level 3 Scene
class Level3Scene: SKScene, SKPhysicsContactDelegate {
    
    var shouldChangeScreen = false
    
    let heart = SKSpriteNode(imageNamed: "heartOff")
    let star = SKSpriteNode(imageNamed: "starOff")
    let circle = SKSpriteNode(imageNamed: "circleOff")
    let square = SKSpriteNode(imageNamed: "squareOff")
    let diamond = SKSpriteNode(imageNamed: "diamondOff")
    
    let heartText = SKLabelNode(text: "off")
    let starText = SKLabelNode(text: "off")
    let circleText = SKLabelNode(text: "off")
    let squareText = SKLabelNode(text: "off")
    let diamondText = SKLabelNode(text: "off")
    
    let shapeSize = CGSize(width: 200, height: 200)
    
    let popUp = SKSpriteNode(color: #colorLiteral(red: 0.300241679, green: 0.6219526529, blue: 0.7733848691, alpha: 1), size: CGSize(width: 1000, height: 400))
    let popUpHeader = SKLabelNode(text: "Level 3a: Objective")
    let popUpText = SKLabelNode(text: """
Oh no… Gator's feeling tired. It’s normal to feel stuck or unmotivated
sometimes. A good way to solve this is to take a small break.

Shapes will slowly drop from the top of the screen.
Click on the matching shape outline(s) to
help Gator recharge!
""")
    let popUpButton = SKSpriteNode(imageNamed: "nextButtonTexture")
    let popUpImage = SKSpriteNode(imageNamed: "levelDiagram")
    let pattern = SKSpriteNode(imageNamed: "com1")
    
    override func didMove(to view: SKView) {
        
        physicsWorld.contactDelegate = self
        
        let shapeArray = [heart, star, circle, square, diamond]
        let shapeTextArray = [heartText, starText, circleText, squareText, diamondText]
        
        
        shapeArray.forEach { shape in
            shape.size = shapeSize
            shape.position.y = 250
        }
        
        shapeTextArray.forEach { shapeText in
            
            shapeText.fontName = "AvenirNext-Heavy"
            shapeText.position.y = 250
            
        }
        heart.position.x = 200
        star.position.x = 400
        circle.position.x = 600
        square.position.x = 800
        diamond.position.x = 1000
        
        heartText.position.x = 200
        starText.position.x = 400
        circleText.position.x = 600
        squareText.position.x = 800
        diamondText.position.x = 1000
        
        pattern.size = CGSize(width: 1000, height: 200)
        pattern.position = CGPoint(x: 590, y: 900)
        
        
        pattern.physicsBody = SKPhysicsBody(rectangleOf: pattern.size)
        
        pattern.physicsBody?.affectedByGravity = false
        pattern.physicsBody?.isDynamic = true
        
        circle.physicsBody = SKPhysicsBody(rectangleOf: circle.size)
        circle.physicsBody?.isDynamic = true
        circle.physicsBody?.affectedByGravity = false
        
        
        pattern.physicsBody?.collisionBitMask = 0
        pattern.physicsBody?.categoryBitMask = PatternCategory
        pattern.physicsBody?.contactTestBitMask = ShapeCategory
        
        circle.physicsBody?.collisionBitMask = 0
        circle.physicsBody?.categoryBitMask = ShapeCategory
        circle.physicsBody?.contactTestBitMask = PatternCategory
       
        
        
        heart.name = "heart"
        star.name = "star"
        circle.name = "circle"
        square.name = "square"
        diamond.name = "diamond"
        
        heartText.name = "heart"
        starText.name = "star"
        circleText.name = "circle"
        squareText.name = "square"
        diamondText.name = "diamond"
        
        
        popUp.position = CGPoint(x: 600, y: 500)
        popUp.zPosition = 5
        
        popUpHeader.horizontalAlignmentMode = .left
        popUpHeader.position = CGPoint(x: 150, y: 600)
        popUpHeader.zPosition = 5
        popUpHeader.fontName = "AvenirNext-Heavy"
        popUpHeader.fontColor = .black
        
        popUpText.position = CGPoint(x: 150, y: 380)
        popUpText.zPosition = 5
        popUpText.fontSize = 24
        popUpText.horizontalAlignmentMode = .left
        popUpText.fontName = "AvenirNext-Medium"
        popUpText.fontColor = .black
        popUpText.numberOfLines = 0
        
        popUpButton.size = CGSize(width: 200, height: 90)
        popUpButton.position = CGPoint(x: 900, y: 380)
        popUpButton.zPosition = 5
        popUpButton.name = "popUpButton"
        
        popUpImage.size = CGSize(width: 600, height: 200)
        popUpImage.position = CGPoint(x: 400, y: 400)
        popUpImage.zPosition = 5
        
        self.addChild(heart)
        self.addChild(star)
        self.addChild(circle)
        self.addChild(square)
        self.addChild(diamond)
        
        
       
        
        self.addChild(pattern)
        
        self.addChild(popUp)
        self.addChild(popUpHeader)
        self.addChild(popUpText)
        self.addChild(popUpButton)
       // self.addChild(popUpImage)
       
       
        
    }
    
   
    
    let patternActionGroup = SKAction.sequence([
        SKAction.move(to: CGPoint(x: 590, y: 900), duration: 0.2),
        SKAction.wait(forDuration: 0.1),
        SKAction.moveTo(y: 350, duration: 5.0)])
    
    func errorMessage() {
        showPopUp()
        popUpText.position = CGPoint(x: 150, y: 450)
        popUpText.text = """
That wasn't right.
Only click on the shape outline if it matches the shape dropping from above.

(Hint: you can select and unselect by clicking on the outline.)
"""
        popUpHeader.text = "Uh oh..."
        pattern.position = CGPoint(x: 590, y: 900)
    }
    
   
    func allOff() {
        
        
        heart.texture = heartOffTexture
        star.texture = starOffTexture
        circle.texture = circleOffTexture
        square.texture = squareOffTexture
        diamond.texture = diamondOffTexture
        
        heartOn = false
        starOn = false
        circleOn = false
        squareOn = false
        diamondOn = false
        
    }
    func didBegin(_ contact: SKPhysicsContact) {
        
            
        var isOnArray = [heartOn,starOn,circleOn,squareOn,diamondOn]
        
        let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
   
   
        switch contactMask {
        case PatternCategory | ShapeCategory:
           print("contact detected")
            
            if textStage == 1 {
                
                if isOnArray == [false, false, true, false, false] {
                   textStage = 2
                    pattern.removeAllActions()
                    pattern.texture = SKTexture(imageNamed: "com2")
                    pattern.run(patternActionGroup)
                    
        
                } else {
                    errorMessage()
                    
                }
                    
                allOff()
                
            } else if textStage == 2 {
                
                if isOnArray == [true, true, false, true, true] {
                   textStage = 3
                    pattern.removeAllActions()
                    pattern.texture = SKTexture(imageNamed: "com3")
                    pattern.run(patternActionGroup)
        
                } else {
                    errorMessage()
                }
                allOff()
                
			} else if textStage == 3 {
				
				if isOnArray == [true, false, true, false, true] {
				   textStage = 4
					pattern.removeAllActions()
					pattern.texture = SKTexture(imageNamed: "com4")
					pattern.run(patternActionGroup)
		
				} else {
                    errorMessage()
				}
                allOff()
				
			} else if textStage == 4 {
				
				if isOnArray == [true, true, true, true, true] {
					showPopUp()
					popUpText.position = CGPoint(x: 150, y: 380)
                    shouldChangeScreen = true
					popUpText.text = """
Thanks to your help, Gator is now recharged and ready to take on his
next task. Remember to give yourself a break once in a while -
this could be taking a nap, drawing a picture, or listening to music!
Don't overwork yourself.

Click next to continue.
"""
					popUpHeader.text = "Great Job!"
					
					
				} else {
                    errorMessage()
                    allOff()
				}
				
				
			}
            
        default:
            print("default")
         }
           
    }
    
    
    var heartOn = false
    var starOn = false
    var circleOn = false
    var squareOn = false
    var diamondOn = false
    
    
    let heartOnTexture = SKTexture(imageNamed: "heartOn")
    let heartOffTexture = SKTexture(imageNamed: "heartOff")
    
    let starOnTexture = SKTexture(imageNamed: "starOn")
    let starOffTexture = SKTexture(imageNamed: "starOff")
    
    let circleOnTexture = SKTexture(imageNamed: "circleOn")
    let circleOffTexture = SKTexture(imageNamed: "circleOff")
    
    let squareOnTexture = SKTexture(imageNamed: "squareOn")
    let squareOffTexture = SKTexture(imageNamed: "squareOff")
    
    let diamondOnTexture = SKTexture(imageNamed: "diamondOn")
    let diamondOffTexture = SKTexture(imageNamed: "diamondOff")
    
    func turnShapeOn(shape: SKSpriteNode, onImage: SKTexture){
        shape.texture = onImage
        
        //shape.size = shapeSize
    }
    
    func turnShapeOff(shape: SKSpriteNode, offImage: SKTexture){
        
        shape.texture = offImage
       
        //shape.size = CGSize(width: 150, height: 150)
    }
    
    
    func showPopUp() {
        popUp.isHidden = false
        popUpText.isHidden = false
        popUpHeader.isHidden = false
        popUpButton.isHidden = false
    }
    
    func hidePopUp() {
        popUp.isHidden = true
        popUpText.isHidden = true
        popUpHeader.isHidden = true
        popUpButton.isHidden = true
    }
    
    
    var textStage = 1
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            
        var isOnArray = [heartOn,starOn,circleOn,squareOn,diamondOn]
        
        for touch in touches {
                let location = touch.location(in: self)
                let touchedNode = atPoint(location)
            
            
                if touchedNode.name == "heart" {
                    
                    
                    if heartOn == true {
                        turnShapeOff(shape: heart, offImage: heartOffTexture)
                        heartOn = false
                        heartText.text = "off"
                        print("heart turned off")
                        
                    } else if heartOn == false {
                        turnShapeOn(shape: heart, onImage: heartOnTexture)
                        heartOn = true
                        heartText.text = "on"
                        print("heart turned on")
                    }
                } else if touchedNode.name == "star" {
                    
                    if starOn == true {
                        turnShapeOff(shape: star, offImage: starOffTexture)
                        starOn = false
                        starText.text = "off"
                        print("star turned off")
                        
                    } else if starOn == false {
                        turnShapeOn(shape: star, onImage: starOnTexture)
                        starOn = true
                        starText.text = "on"
                        print("star turned on")
                    }
                    
                } else if touchedNode.name == "circle" {
                    
                    if circleOn == true {
                        turnShapeOff(shape: circle, offImage: circleOffTexture)
                        circleOn = false
                        circleText.text = "off"
                        print("circle turned off")
                        
                    } else if circleOn == false {
                        turnShapeOn(shape: circle, onImage: circleOnTexture)
                        circleOn = true
                        circleText.text = "on"
                        print("circle turned on")
                    }
                    
                } else if touchedNode.name == "square" {
                    
                    if squareOn == true {
                        turnShapeOff(shape: square, offImage: squareOffTexture)
                        squareOn = false
                        squareText.text = "off"
                        print("square turned off")
                        
                    } else if squareOn == false {
                        turnShapeOn(shape: square, onImage: squareOnTexture)
                        squareOn = true
                        squareText.text = "on"
                        print("square turned on")
                    }
                    
                } else if touchedNode.name == "diamond" {
                    
                    if diamondOn == true {
                        turnShapeOff(shape: diamond, offImage: diamondOffTexture)
                        diamondOn = false
                        diamondText.text = "off"
                        print("diamond turned off")
                        
                    } else if diamondOn == false {
                        turnShapeOn(shape: diamond, onImage: diamondOnTexture)
                        diamondOn = true
                        diamondText.text = "on"
                        print("diamond turned on")
                    }
                    
                } else if touchedNode.name == "popUpButton" {
                    
                    if shouldChangeScreen == true {
                        
                        var scene:SKScene = Level3GameScene(size: self.size)
                        self.view?.presentScene(scene)
                        
                    } else {
                        
                        hidePopUp()
                        pattern.position = CGPoint(x: 590, y: 900)
                        pattern.run(SKAction.moveTo(y: 350, duration: 5.0))
                       
                    }
                   
                }
            
            isOnArray = [heartOn,starOn,circleOn,squareOn,diamondOn]
            
        }
    }
    
}

class RecapScene: SKScene {
    
    
    
    let pageHeader = SKLabelNode(text: "Level Recap")
    let pageText = SKLabelNode(text: """

While playing this game, you read small tips
on how to combat procrastination.
Want more detail on what you learned?
Click on each level thumbnail for more info!
""")
    
    let colorBg = SKSpriteNode(color: #colorLiteral(red: 0.6561499834, green: 0.7975469232, blue: 0.5675188303, alpha: 1), size: CGSize(width: 1200, height: 1000))
    let sideBg = SKSpriteNode(color: #colorLiteral(red: 0.9392343163, green: 1, blue: 0.8662324548, alpha: 1), size: CGSize(width: 480, height: 700))
    let sideHeader = SKLabelNode(text: "header placeholder")
    let sideText = SKLabelNode(text: "text placeholder")
    let indicator = SKSpriteNode(color: .orange, size: CGSize(width: 270, height: 220))
    
    let tn1 = SKSpriteNode(imageNamed: "tn1")
    let tn2 = SKSpriteNode(imageNamed: "tn2")
    let tn3 = SKSpriteNode(imageNamed: "tn3")
    
    let button = SKSpriteNode(imageNamed: "nextButtonTexture")
    
    override func didMove(to view: SKView) {
        
        let tnSize = CGSize(width: 250, height: 200)
        
        indicator.isHidden = true
        
        pageHeader.horizontalAlignmentMode = .left
        pageHeader.position = CGPoint(x: 120, y: 800)
        pageHeader.zPosition = 5
        pageHeader.fontName = "AvenirNext-Heavy"
        pageHeader.fontColor = .black
        
        pageText.position = CGPoint(x: 120, y: 650)
        pageText.zPosition = 5
        pageText.fontSize = 24
        pageText.horizontalAlignmentMode = .left
        pageText.fontName = "AvenirNext-Medium"
        pageText.fontColor = .black
        pageText.numberOfLines = 0
        
        colorBg.position = CGPoint(x: 600, y: 500)
        colorBg.zPosition = -3
        
        sideBg.position = CGPoint(x: 900, y: 500)
        
        sideHeader.horizontalAlignmentMode = .left
        sideHeader.position = CGPoint(x: 690, y: 790)
        sideHeader.zPosition = 5
        sideHeader.fontName = "AvenirNext-Heavy"
        sideHeader.fontColor = .black
        sideHeader.fontSize = 26
        
        sideText.position = CGPoint(x: 690, y: 300)
        sideText.zPosition = 5
        sideText.fontSize = 23
        sideText.horizontalAlignmentMode = .left
        sideText.fontName = "AvenirNext-Medium"
        sideText.fontColor = .black
        sideText.numberOfLines = 0
        
        sideHeader.isHidden = true
        sideText.isHidden = true
        
        tn1.position = CGPoint(x: 250, y: 500)
        tn1.size = tnSize
        tn1.name = "tn1"
        
        tn2.position = CGPoint(x: 510, y: 500)
        tn2.size = tnSize
        tn1.name = "tn2"
        
        tn3.position = CGPoint(x: 250, y: 275)
        tn3.size = tnSize
        tn1.name = "tn3"
        
        button.size = CGSize(width: 200, height: 90)
        button.position = CGPoint(x: 500, y: 250)
        button.zPosition = 5
        button.name = "button"

        indicator.zPosition = -1
        
        self.addChild(pageHeader)
        self.addChild(pageText)
        self.addChild(colorBg)
        self.addChild(sideBg)
        self.addChild(sideHeader)
        self.addChild(sideText)
        self.addChild(tn1)
        self.addChild(tn2)
        self.addChild(tn3)
        self.addChild(indicator)
        self.addChild(button)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            
        tn1.name = "tn1"
        tn2.name = "tn2"
        tn3.name = "tn3"
        
        for touch in touches {
            
                    let location = touch.location(in: self)
                    let touchedNode = atPoint(location)
                      if touchedNode.name == "tn1" {
                          sideHeader.isHidden = false
                          sideText.isHidden = false
                          indicator.isHidden = false
                          sideText.position.y = 265
                          sideHeader.text = "Lvl 1: Creating Lists"
                          sideText.text = """
In level 1, we learned how to
create a to-do list and
prioritise tasks.

Try adding due dates or using a to-do
app like Reminders to set deadlines
and notifications. You could also make
different lists for separate projects,
timeframes, or priority levels!

Gator reminds you that although
having a to-do list is good,
make sure the tasks you set
are achievable. A 9-page essay
will probably need more than
one hour to write.
"""
                          indicator.position = tn1.position
                          
                      } else if touchedNode.name == "tn2" {
                          sideHeader.isHidden = false
                          sideText.isHidden = false
                          indicator.isHidden = false
                          sideHeader.text = "Lvl 2: Eliminating Distractions"
                          sideText.text = """
In level 2, we learned how to eliminate
distractions.
Eliminating distractions could mean
putting away non-essential electronics
while working, working in a library,
or even listening to instrumental music.

Of course, eliminating distractions in
real life isn't as fun as flinging
falling meteorites from the sky,
but it's equally effective.
Gator notes that using earphones to
block-out noises helps as well.
"""
                          sideText.position.y = 300
                          indicator.position = tn2.position

                          
                      } else if touchedNode.name == "tn3" {
                          sideHeader.isHidden = false
                          sideText.isHidden = false
                          indicator.isHidden = false
                          sideText.position.y = 180
                          sideHeader.text = "Lvl 3: Taking Breaks"
                          indicator.position = tn3.position
                          sideText.text = """
In level 3, we learned how to
maximise productivity by taking
breaks.
Working in shorter intervals helps to
prevent burn-out and stress!
The shape combinations represent
what a break means. To some, a break
might mean playing an
instrument. To others, it may mean
meditating or taking a short nap.

Gator recommends the
Pomodoro method:
Set a timer for 25 minutes and work
until it’s completed. Then, set a timer
for 5 minutes and take a break.

Do this a few times,
then take a longer break!
"""

                      } else if touchedNode.name == "button" {
                          
                          var scene:SKScene = GatorDialogue(size: self.size)
                        self.view?.presentScene(scene)
                      }
            }
    }
    
}

class Level3GameScene: SKScene, SKPhysicsContactDelegate {
    
    var shouldChangeScreen = false
    
    
    let binCategory:    UInt32 = 1 << 1
    let trashCategory:   UInt32 = 1 << 2
    
    let bg = SKSpriteNode(imageNamed: "titleBg1")
    let popUp = SKSpriteNode(color: #colorLiteral(red: 0.300241679, green: 0.6219526529, blue: 0.7733848691, alpha: 1), size: CGSize(width: 1000, height: 400))
    let popUpHeader = SKLabelNode(text: "Level 3b: Objective")
    let popUpText = SKLabelNode(text: """
Now that Gator is recharged and ready to go,
it's time to tackle that final task on his list:
Tidying up his swamp!

Drag the trash bags around his pond into the trashbin.

""")
    
    let popUpButton = SKSpriteNode(imageNamed: "nextButtonTexture")
    let popUpImage = SKSpriteNode(imageNamed: "trashbin")
    
    let trashbin = SKSpriteNode(imageNamed: "trashbin")
    let trash1 = SKSpriteNode(imageNamed: "trash3")
    let trash2 = SKSpriteNode(imageNamed: "trash3")
    let trash3 = SKSpriteNode(imageNamed: "trash3")
    let trash4 = SKSpriteNode(imageNamed: "trash3")
    let trash5 = SKSpriteNode(imageNamed: "trash3")
    
    
    
    override func didMove(to view: SKView) {
        
        
        physicsWorld.contactDelegate = self
        
        
        bg.position = CGPoint(x: 600, y: 500)
        bg.size = CGSize(width: 1200, height: 1000)
        popUp.position = CGPoint(x: 600, y: 500)
        
        popUp.zPosition = 5
        
        popUpHeader.horizontalAlignmentMode = .left
        popUpHeader.position = CGPoint(x: 150, y: 600)
        popUpHeader.zPosition = 5
        popUpHeader.fontName = "AvenirNext-Heavy"
        popUpHeader.fontColor = .black
        
        popUpText.position = CGPoint(x: 150, y: 380)
        popUpText.zPosition = 5
        popUpText.fontSize = 24
        popUpText.horizontalAlignmentMode = .left
        popUpText.fontName = "AvenirNext-Medium"
        popUpText.fontColor = .black
        popUpText.numberOfLines = 0
        
        popUpButton.size = CGSize(width: 200, height: 90)
        popUpButton.position = CGPoint(x: 900, y: 380)
        popUpButton.zPosition = 5
        popUpButton.name = "popUpButton"
        
        popUpImage.size = CGSize(width: 200, height: 250)
        popUpImage.position = CGPoint(x: 900, y: 550)
        popUpImage.zPosition = 5
        
        trashbin.size = CGSize(width: 150, height: 200)
        trashbin.position = CGPoint(x: 200, y: 700)
        trashbin.zPosition = 5
        trashbin.isHidden = true
        
        trashbin.physicsBody = SKPhysicsBody(rectangleOf: trashbin.size)
        trashbin.physicsBody?.affectedByGravity = false
        trashbin.physicsBody?.isDynamic = true
        
        
        trashbin.physicsBody?.categoryBitMask = binCategory
        trashbin.physicsBody?.contactTestBitMask = trashCategory
        trashbin.physicsBody?.collisionBitMask = 0
        
        var trashArray = [trash1, trash2, trash3, trash4, trash5]
        
        
        trashArray.forEach { trash in
            
            let randomX = Int.random(in: 200..<1000)
            let randomY = Int.random(in: 200..<500)
            
            trash.size = CGSize(width: 100, height: 100)
            trash.position = CGPoint(x: randomX, y: randomY)
            trash.physicsBody = SKPhysicsBody(rectangleOf: trash.size)
            trash.physicsBody?.categoryBitMask = trashCategory
            trash.physicsBody?.collisionBitMask = 0
            trash.physicsBody?.contactTestBitMask = binCategory
            trash.physicsBody?.affectedByGravity = false
            trash.physicsBody?.isDynamic = true
            trash.zPosition = 5
            trash.isHidden = false
            self.addChild(trash)
        }
        
        
        
        self.addChild(bg)
        self.addChild(popUp)
        self.addChild(popUpText)
        self.addChild(popUpButton)
        self.addChild(popUpHeader)
        self.addChild(popUpImage)
        self.addChild(trashbin)
       
        
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        switch contactMask {
        case binCategory | trashCategory:
            
            if trashCounter == 5 {
                print("level complete")
                popUp.isHidden = false
                trashbin.removeAllActions()
                trashbin.removeFromParent()
                
                shouldChangeScreen = true
                popUpHeader.isHidden = false
                popUpText.isHidden = false
                popUpButton.isHidden = false
                
                popUpHeader.text = "Great Work!"
                popUpText.position.y = 450
                popUpText.text = """
Amazing! You just helped Gator finish the last task on his to-do list.
He's all done for today, thanks to your help! Give yourself a pat on the back.

Click next for a quick recap on all the levels - and all you've learned!

"""
            } else if trashCounter < 6 {
                contact.bodyA.node?.removeFromParent()
                trashCounter += 1
                
            }
            
            
            
        default:
            print("other contact")
            
        }
        
        }
    
    
    var trashSpawnCounter = 0
    
    
    
    var trashCounter = 1
    
    var movableNode : SKNode?
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        var trashArray = [trash1, trash2, trash3, trash4, trash5]
        
        bg.texture = SKTexture(imageNamed: "titleBg2")
        if let touch = touches.first {
            let location = touch.location(in: self)
            
            trashArray.forEach { trash in
                if trash.contains(location) {
                        movableNode = trash
                        movableNode!.position = location
                    }
                
             }
            
            }
        
        var right = SKAction.move(to: CGPoint(x: 1000, y: trashbin.position.y), duration: 4)
        var left = SKAction.move(to: CGPoint(x: 200, y: trashbin.position.y), duration: 4)
        
        var binSequence = SKAction.sequence([right,left])
        
        
        for touch in touches {
                      let location = touch.location(in: self)
                      let touchedNode = atPoint(location)
                      if touchedNode.name == "popUpButton" {
                          
                          if shouldChangeScreen == false {
                              
                          
                          popUp.isHidden = true
                          popUpText.isHidden = true
                          popUpButton.isHidden = true
                          popUpImage.isHidden = true
                          popUpHeader.isHidden = true
                          
                          trashbin.isHidden = false
                          trashbin.run(SKAction.repeatForever(binSequence))
                          
                          } else if shouldChangeScreen == true {
                              
                              var scene:SKScene = RecapScene(size: self.size)
                                               self.view?.presentScene(scene)
                          }
                          
                      }
                 }
        
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let touch = touches.first, movableNode != nil {
            movableNode!.position = touch.location(in: self)
            }
        
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, movableNode != nil {
            movableNode!.position = touch.location(in: self)
            movableNode = nil
        }
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            movableNode = nil
        }
    }
    
}

class GatorDialogue: SKScene {
    
    let colorBg = SKSpriteNode(color: #colorLiteral(red: 0.6561499834, green: 0.7975469232, blue: 0.5675188303, alpha: 1), size: CGSize(width: 1200, height: 1000))
    
    let gatorSpeechBg = SKSpriteNode(color: #colorLiteral(red: 0.6876877546, green: 0.9086436629, blue: 0.9380626678, alpha: 1) , size: CGSize(width: 1000, height: 400))
    let gatorSpeechText = SKLabelNode(text: """

Thanks for helping me out today. I really appreciate it.

I hope you had a fun time learning about procrastination.

I bid you farewell, friend!

""")
    let gatorSpeechHeader = SKLabelNode(text: "Gator")
    let gatorSpeechPic = SKSpriteNode(imageNamed: "gator_walk_right_1")
    
    let seeYa = SKSpriteNode(imageNamed: "seeYaButtonTexture")
    
    
    override func didMove(to view: SKView) {
        
        colorBg.position = CGPoint(x: 600, y: 500)
        
        gatorSpeechBg.position = CGPoint(x: 600, y: 400)
        gatorSpeechBg.zPosition = 1
        
        gatorSpeechText.fontName = "AvenirNext-Medium"
        gatorSpeechText.fontSize = 28.0
        gatorSpeechText.numberOfLines = 0
        gatorSpeechText.horizontalAlignmentMode = .left
        gatorSpeechText.position = CGPoint(x: 150, y: 300)
        gatorSpeechText.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        gatorSpeechText.zPosition = 3
        
        gatorSpeechHeader.position = CGPoint(x: 150, y: 500)
        gatorSpeechHeader.horizontalAlignmentMode = .left
        gatorSpeechHeader.fontSize = 38.0
        gatorSpeechHeader.fontName = "AvenirNext-Heavy"
        gatorSpeechHeader.numberOfLines = 0
        gatorSpeechHeader.fontColor = #colorLiteral(red: 0.2226293087, green: 0.06425824016, blue: 0.3632079363, alpha: 1)
        gatorSpeechHeader.zPosition = 3
        
        
        gatorSpeechPic.size = CGSize(width: 550, height: 225)
        gatorSpeechPic.position = CGPoint(x: 400, y: 680)
        gatorSpeechPic.zPosition = 0
        
        seeYa.size = CGSize(width: 200, height: 90)
        seeYa.position = CGPoint(x: 950, y: 280)
        seeYa.zPosition = 3
        seeYa.name = "seeYa"
        
        self.addChild(seeYa)
        self.addChild(colorBg)
        self.addChild(gatorSpeechBg)
        self.addChild(gatorSpeechPic)
        self.addChild(gatorSpeechText)
        self.addChild(gatorSpeechHeader)
    }
        
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            
        for touch in touches {
                      let location = touch.location(in: self)
                      let touchedNode = atPoint(location)
                      if touchedNode.name == "seeYa" {
                          var scene:SKScene = EndScene(size: self.size)
                                           self.view?.presentScene(scene)
                      }
                }
    }
    
}

class EndScene: SKScene {
    
    let colorBg = SKSpriteNode(color: .systemGreen, size: CGSize( width: 1200, height: 1000))
    let text = SKLabelNode(text: """
Thanks for playing!
""")
    let button = SKSpriteNode(imageNamed: "playAgainButtonTexture")
    
    override func didMove(to view: SKView) {
        
        colorBg.position = CGPoint(x: 600, y: 500)
        colorBg.color = #colorLiteral(red: 0.6378648877, green: 0.7980249524, blue: 0.5365267396, alpha: 1)
        colorBg.zPosition = -3
        
        text.fontName = "AvenirNext-Heavy"
        text.fontSize = 36.0
        text.numberOfLines = 0
        text.position = CGPoint(x: 600, y: 500)
        text.fontColor = #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1)
        text.zPosition = 3
        
        button.size = CGSize(width: 200, height: 90)
        button.position = CGPoint(x: 600, y: 380)
        button.zPosition = 5
        button.name = "button"
        
        self.addChild(text)
        self.addChild(colorBg)
        self.addChild(button)
        
    }
        
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            
        for touch in touches {
                      let location = touch.location(in: self)
                      let touchedNode = atPoint(location)
                      if touchedNode.name == "button" {
                          var scene:SKScene = TitleScene(size: self.size)
                        self.view?.presentScene(scene)
                                          
                      }
                 }
    }
    
}

struct ContentView: View {
    var scene: SKScene {
        
        let scene = TitleScene()
        scene.size = CGSize( width: 1200, height: 1000)
        scene.scaleMode = .fill
        return scene
    }
    
    

    var body: some View {
        SpriteView(scene: scene)
            .frame(width: 1200, height: 1000)
            .ignoresSafeArea()
    }
}






